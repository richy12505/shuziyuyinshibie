
function hmm=train()
clear;
clc;
for i=1:10
    for j=1:10
        fname = sprintf('train\\%d%d.wav', i-1,j-1);
        samples{i}{j}=audioread(fname);
    end
end
save 'samples.mat' samples;
 
for i=1:length(samples)
    sample=[];
    for k=1:length(samples{i})
        sample(k).wave=samples{i}{k};
        sample(k).data=[];
    end
    str = sprintf('����ѵ����%d��HMMģ��', i);
    disp(str);
    hmm{i}=trainhmm(sample,[3 3 3 3]);
    disp(['��' int2str(i) '��HMMģ��ѵ����ϣ�']);
    save 'hmm.mat' hmm;
end

clear str i k j sample;